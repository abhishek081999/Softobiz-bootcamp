module.exports = function(app) {
  var taskController = require('../controllers/taskcontroller');
  app.route('/api/tasks')
     .get(taskController.getAll)
     .post(taskController.insert);
   
  app.route('/api/tasks/:taskId')
      .get(taskController.getBy)
      .put(taskController.update)
      .delete(taskController.remove);
};