import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CartComponent } from './cart/cart.component';
import { ListComponent } from '../catalog/list/list.component';
import { ItemComponent } from './item/item.component';


@NgModule({
  declarations: [
                  CartComponent,
                  ListComponent,
                  ItemComponent,

  ],
  imports: [
    CommonModule
  ],
  exports:[
    CartComponent,
    ItemComponent
  ]
})
export class ShoppingCartModule { }
