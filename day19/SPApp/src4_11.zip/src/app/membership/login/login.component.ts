import { HttpClient } from '@angular/common/http';
import { Component, OnInit,OnDestroy } from '@angular/core';
import { Credential } from './credential';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit,OnDestroy { 
   
  private count:Number| undefined;

  //Hollywood Design Principle
  //Do not call me, I will call you.

  public user:Credential=new Credential("","");
  public restapiUrl="http://localhost:7777/api/authenticate";

  constructor(private http:HttpClient) { 
    console.log("Login component constructor invoked...");
  }

  //Component Life cycle event 
  ngOnInit(): void {
    console.log("Login component onInit invoked...");
  }

  ngOnDestroy():void{
    console.log("Login component onDestroy invoked...");
  }

  onSubmit():void{
    console.log(this.user);
    console.log("form submit event occured....");
    this.http.post(this.restapiUrl,this.user).subscribe(
    (data) => {
        console.log(data);
    }
    );
  }
}
