import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-net-banking',
  templateUrl: './net-banking.component.html',
  styleUrls: ['./net-banking.component.css']
})
export class NetBankingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
