import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.css']
})
export class DetailsComponent implements OnInit {

   title:string|undefined;
   description:string|undefined;
   unitprice:number=0;
   quantity:number=0;
   likes:number=0;
   imageurl:string="/assets/images/rose.jpg";

  constructor() { }

  ngOnInit(): void {

   this.title="Rose";
   this.description="Valentine Flower";
   this.unitprice=12;
   this.quantity=1;
   this.likes=7600;
   this.imageurl="/assets/images/rose.jpg";
  }

   //Event Handler
  onUpdate(ee:any):void{
    this.likes=ee.count;
  }
}
