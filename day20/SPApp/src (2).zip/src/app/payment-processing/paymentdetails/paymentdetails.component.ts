import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-paymentdetails',
  templateUrl: './paymentdetails.component.html',
  styleUrls: ['./paymentdetails.component.css']
})
export class PaymentdetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}



