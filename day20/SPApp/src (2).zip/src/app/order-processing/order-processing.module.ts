import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { OrdersComponent } from './orders/orders.component';
import { OrderdetailsComponent } from './orderdetails/orderdetails.component';



@NgModule({
  declarations: [
    OrdersComponent,
    OrderdetailsComponent
  ],
  imports: [
    CommonModule
  ]
})
export class OrderProcessingModule { }
