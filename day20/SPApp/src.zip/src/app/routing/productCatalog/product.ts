export class Product{
    constructor(
                public ID:number,
                public title:string,
                public description:string,
                public unitPrice:number,
                public balance:number){}
}